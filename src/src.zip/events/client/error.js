module.exports = (Discord, error) => {
    console.log(error)
}