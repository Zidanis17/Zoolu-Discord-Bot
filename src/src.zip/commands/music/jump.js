module.exports = {
    name:'jump',
    description:'Jump to the song you desire in a queue ',
    type:'music',
    usage:'>jump <number of song you want to jump to in the queue>',
    execute(client, message, args, Discord){
        const queue = client.music.getQueue(message.guild.id)
        if(!queue) return(message.reply('No song, so no loop!'))
        if(isNaN(parseInt(args[0]))) return message.reply('Please enter a real number')
        if(parseInt(args[0]) < 0 ) return message.reply('Number Must not be smaller than 0')


        queue.jump(parseInt(args[0]) - 1)
        return message.react('✅')
    }
}