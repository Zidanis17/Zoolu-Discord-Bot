module.exports = {
    name: 'resume',
    description:'resume the song',
    type:'music',
    usage:'>resume',
    async execute(client, message, args, Discord){
        const queue = client.music.getQueue(message.guild.id);
        if(!queue) return(message.reply('No song, so no resume!'));
        queue.setPaused(false);
        message.react('▶️');
        return
    }
}