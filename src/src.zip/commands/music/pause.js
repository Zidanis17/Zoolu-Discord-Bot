module.exports = {
    name: 'pause',
    description:'Pauses a song',
    type:'music',
    usage:'>pause',
    async execute(client, message, args, Discord){
        const queue = client.music.getQueue(message.guild.id)
        if(!queue) return(message.reply('No queue, so no pause!'))
        queue.setPaused(true)
        message.react('⏸')
        return
    }
}