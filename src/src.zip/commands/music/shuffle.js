module.exports = {
    name:'shuffle',
    description:'Shuffles a queue',
    type:'music',
    usage:'>shuffle',
    execute(client, message, args, Discord){
        const queue = client.music.getQueue(message.guild.id)
        if(!queue) return message.reply('No queue, so no shuffle')
        queue.shuffle()
        return message.react('🔀')
    }
}