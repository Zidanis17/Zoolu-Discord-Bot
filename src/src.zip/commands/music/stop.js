module.exports = {
    name: 'stop',
    description:'Stops the song',
    type:'music',
    usage:'>stop',
    aliases: ['leave'],
    async execute(client, message, args, Discord){
        const queue = client.music.getQueue(message.guild.id)
        if(!queue) return(message.reply('No song, so no stop!'))

        queue.stop()
        return message.react('🛑')
    }
}