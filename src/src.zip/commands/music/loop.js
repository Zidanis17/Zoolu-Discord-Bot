const {QueueRepeatMode} = require('discord-player')
module.exports = {
    name: 'loop',
    description:'Loops a song',
    type:'music',
    usage:'>loop',
    async execute(client, message, args, Discord){
        const queue = client.music.getQueue(message.guild.id)
        if(!queue) return(message.reply('No song, so no loop!'))
        
        let mode = (queue.repeatMode + 1) > 2 ? 0 : queue.repeatMode + 1 
        switch(mode) {
            case 0:
                mode = "Off";
                break;
            case 1:
                mode = "Repeat Song";
                break;
            case 2:
                mode = "Repeat Queue";
                break;
        }
        message.reply("Set repeat mode to `" + mode + "`");
        return
    }
}