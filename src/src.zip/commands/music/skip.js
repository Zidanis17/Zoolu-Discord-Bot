module.exports = {
    name: 'skip',
    description:'Skips a song',
    type:'music',
    usage:'>skip',
    async execute(client, message, args, Discord){
        const queue = client.music.getQueue(message.guild.id)
        if(!queue) return message.reply('No queue, so no skip')
        queue.skip()
    }
}