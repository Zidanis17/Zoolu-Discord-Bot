const Games = require('./src/games')

module.exports = {Games}